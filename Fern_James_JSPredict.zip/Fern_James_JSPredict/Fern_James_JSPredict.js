function myBirthYearFunc(){
    console.log("I was born in" + 1980);
}
myBirthYearFunc();

//this will say 'I was born in 1980'
//(in actuality it said "I was born in1980"

function myBirthYearFunc(){
    console.log("I was born in" + 1980);
}
myBirthYearFunc();
//should be "I was born in1980" again
// it was

function add(num1, num2){
    console.log("Summing Numbers!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    console.log(sum);
}
add(10, 20);
// should be "Summing Numbers!num 1 is:10num2 is:2030"
// nvm, there was a space after the colons, so it is actually num1 is: 10, instead of num1 is:10
// and then different console.logs show their logs on different lines 
