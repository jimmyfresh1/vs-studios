// declares a variable named likeCount
var likeCount = 0;
// declares  a type of function named increaseLikes
function increaseLikes() {
    // whenever the function is called, likes increased by one
    likeCount = likeCount + 1;
}
