
// Declared Variables for minimum ride requirements
var minimum_age = 11;
var minimum_height = 43;
// Declared variables for messages to show
var message = 'Get on that ride!'
var message2 = 'Sorry kiddo. Maybe next year.'


if (minimum_height >= 42 && minimum_age>=10) {
    console.log(message);
}   else { 
    console.log(message2);
}   /*else if(minimum_height<42) {
    console.log(message2)
    }*/